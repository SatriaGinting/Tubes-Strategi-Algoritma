import time

# Sudoku yang harus di selesaikan
sudoku = [
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 2, 0, 3, 4, 5, 6, 7],
    [0, 3, 4, 5, 0, 6, 1, 8, 2],
    [0, 0, 1, 0, 5, 8, 2, 0, 6],
    [0, 0, 8, 6, 0, 0, 0, 0, 1],
    [0, 2, 0, 0, 0, 7, 0, 5, 0],
    [0, 0, 3, 7, 0, 5, 0, 2, 8],
    [0, 8, 0, 0, 6, 0, 7, 0, 0],
    [2, 0, 7, 0, 8, 3, 6, 1, 5]
]
# print sudoku
def printsudoku(sudoku):
    for i in range(0, 9):
        for j in range(0, 9):
            print(sudoku[i][j], end=" ")
        print()

# memeriksa setiap block
def check(sudoku, row, collumn, val):
    for j in range(0, 9):
        if sudoku[row][j] == val:
            return False

    for i in range(0, 9):
        if sudoku[i][collumn] == val:
            return False

    mulairow = (row // 3) * 3
    mulaicollumn = (collumn // 3) * 3
    for i in range(0, 3):
        for j in range(0, 3):
            if sudoku[mulairow+i][mulaicollumn+j] == val:
                return False
    return True

# backtrack
def backtrack():
    for i in range(0, 9):
        for j in range(0, 9):
            if sudoku[i][j] == 0:
                for val in range(1, 10):
                    if check(sudoku, i, j, val):
                        sudoku[i][j] = val
                        backtrack()

                        sudoku[i][j] = 0
                return          
    printsudoku(sudoku)

mulai = time.time()
backtrack()
berhenti = time.time()
total = berhenti - mulai
print(str(total))
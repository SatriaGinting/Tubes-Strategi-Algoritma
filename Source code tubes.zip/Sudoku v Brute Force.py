import time

# Sudoku yang harus di selesaikan
boardsudoku = [ 
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 2, 0, 3, 4, 5, 6, 7],
    [0, 3, 4, 5, 0, 6, 1, 8, 2],
    [0, 0, 1, 0, 5, 8, 2, 0, 6],
    [0, 0, 8, 6, 0, 0, 0, 0, 1],
    [0, 2, 0, 0, 0, 7, 0, 5, 0],
    [0, 0, 3, 7, 0, 5, 0, 2, 8],
    [0, 8, 0, 0, 6, 0, 7, 0, 0],
    [2, 0, 7, 0, 8, 3, 6, 1, 5]
]
            
# Mencari Angka di setiap block
s = ''.join(map(str,[''.join(map(str, i)) for i in boardsudoku]))

# Convert dari List menjadi Board Sudoku
def buatboard(sudoku):
    for r in range(len(sudoku)):
        if r == 0 or r == 3 or r == 6:
            print("+-------+-------+-------+")
        for c in range(len(sudoku[r])):
            if c == 0 or c == 3 or c == 6:
                print("| ", end= "")
            if sudoku[r][c] != 0:
                print(sudoku[r][c], end= " ")
            else:
                print(end= "  ")
            if c == 8:
                print("|")
    print("+-------+-------+-------+")

# Merubah seluruh string menjadi puzzle sudoku
def convertstring(s):
    solusi = []
    for i in range (len(s)):
        if i % 9 == 0:
            temp = []
            for j in s[i:i+9]:
                temp.append(int(j))
            solusi.append(temp)
    return solusi

# Mencari Row yang sama
def row(i,j):
    if i//9 == j//9:
        return True
    return False

# Mencari Collumn yang sama
def collumn(i,j):
    if i%9 == j%9:
        return True
    return False

# Mencari Block yang sama
def block(i,j):
    if((i//9)//3 == (j//9)//3) & ((i%9)//3 == (j%9)//3):
        return True
    return False

# Brute Force
def bruteforce(s):
    
    # Mencari angka 0
    i = s.find('0')

    # Mencari angka yang bisa di isi ke block
    angkatersedia = {s[j] for j in range (len(s)) if row(i,j) | collumn(i,j) | block(i,j)}
    kemungkinan = {str(i) for i in range(10)} - angkatersedia

    # Memasukan angka yang bisa di isi ke block
    for val in kemungkinan:
        s = s[0:i] + val + s[i+1: ]
        bruteforce(s)
        if s.find('0') == -1:
            buatboard(convertstring(s))

# Main Code  
mulai = time.time()
print("Solusi")
bruteforce(s)
berhenti = time.time()
total = berhenti - mulai
print(str(total))